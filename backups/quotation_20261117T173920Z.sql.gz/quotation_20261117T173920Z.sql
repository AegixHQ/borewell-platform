--
-- PostgreSQL database dump
--

\restrict hnzCliaGGrifw5soFW8XbdrlFH8h2Hsh8YeXUwwmFmDfg85HhOJDPi6iJslWJAJ

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: borewell
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO borewell;

--
-- Name: pricing_rules; Type: TABLE; Schema: public; Owner: borewell
--

CREATE TABLE public.pricing_rules (
    id character varying(36) NOT NULL,
    contractor_id character varying(36) NOT NULL,
    job_type character varying NOT NULL,
    base_rate_per_ft numeric(12,2) NOT NULL,
    casing_rate_per_ft numeric(12,2) NOT NULL,
    labour_flat_fee numeric(12,2) NOT NULL,
    transport_flat_fee numeric(12,2) NOT NULL,
    equipment_flat_fee numeric(12,2) NOT NULL,
    installation_flat_fee numeric(12,2) NOT NULL,
    margin_percent double precision NOT NULL,
    minimum_job_charge numeric(12,2) NOT NULL,
    assumed_depth_ft double precision NOT NULL,
    depth_confidence_band_ft double precision NOT NULL,
    depth_overage_rate_per_ft numeric(12,2) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.pricing_rules OWNER TO borewell;

--
-- Name: quotations; Type: TABLE; Schema: public; Owner: borewell
--

CREATE TABLE public.quotations (
    id character varying(36) NOT NULL,
    job_id character varying(36) NOT NULL,
    contractor_id character varying(36) NOT NULL,
    job_type character varying NOT NULL,
    version integer NOT NULL,
    status character varying NOT NULL,
    line_items json NOT NULL,
    subtotal numeric(12,2) NOT NULL,
    margin_amount numeric(12,2) NOT NULL,
    total numeric(12,2) NOT NULL,
    minimum_charge_applied boolean NOT NULL,
    estimated_depth_min_ft double precision NOT NULL,
    estimated_depth_max_ft double precision NOT NULL,
    confidence character varying NOT NULL,
    created_at timestamp without time zone,
    customer_id character varying(36) NOT NULL,
    depth_overage_rate_per_ft numeric(12,2),
    walk_in boolean DEFAULT false NOT NULL,
    decided_by character varying(36)
);


ALTER TABLE public.quotations OWNER TO borewell;

--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: borewell
--

COPY public.alembic_version (version_num) FROM stdin;
0004
\.


--
-- Data for Name: pricing_rules; Type: TABLE DATA; Schema: public; Owner: borewell
--

COPY public.pricing_rules (id, contractor_id, job_type, base_rate_per_ft, casing_rate_per_ft, labour_flat_fee, transport_flat_fee, equipment_flat_fee, installation_flat_fee, margin_percent, minimum_job_charge, assumed_depth_ft, depth_confidence_band_ft, depth_overage_rate_per_ft, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: quotations; Type: TABLE DATA; Schema: public; Owner: borewell
--

COPY public.quotations (id, job_id, contractor_id, job_type, version, status, line_items, subtotal, margin_amount, total, minimum_charge_applied, estimated_depth_min_ft, estimated_depth_max_ft, confidence, created_at, customer_id, depth_overage_rate_per_ft, walk_in, decided_by) FROM stdin;
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: borewell
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: pricing_rules pricing_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: borewell
--

ALTER TABLE ONLY public.pricing_rules
    ADD CONSTRAINT pricing_rules_pkey PRIMARY KEY (id);


--
-- Name: quotations quotations_pkey; Type: CONSTRAINT; Schema: public; Owner: borewell
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_pkey PRIMARY KEY (id);


--
-- Name: pricing_rules uq_pricing_rules_contractor_job_type; Type: CONSTRAINT; Schema: public; Owner: borewell
--

ALTER TABLE ONLY public.pricing_rules
    ADD CONSTRAINT uq_pricing_rules_contractor_job_type UNIQUE (contractor_id, job_type);


--
-- Name: ix_pricing_rules_contractor_id; Type: INDEX; Schema: public; Owner: borewell
--

CREATE INDEX ix_pricing_rules_contractor_id ON public.pricing_rules USING btree (contractor_id);


--
-- Name: ix_quotations_contractor_id; Type: INDEX; Schema: public; Owner: borewell
--

CREATE INDEX ix_quotations_contractor_id ON public.quotations USING btree (contractor_id);


--
-- Name: ix_quotations_customer_id; Type: INDEX; Schema: public; Owner: borewell
--

CREATE INDEX ix_quotations_customer_id ON public.quotations USING btree (customer_id);


--
-- Name: ix_quotations_job_id; Type: INDEX; Schema: public; Owner: borewell
--

CREATE INDEX ix_quotations_job_id ON public.quotations USING btree (job_id);


--
-- Name: ix_quotations_job_id_version; Type: INDEX; Schema: public; Owner: borewell
--

CREATE INDEX ix_quotations_job_id_version ON public.quotations USING btree (job_id, version);


--
-- PostgreSQL database dump complete
--

\unrestrict hnzCliaGGrifw5soFW8XbdrlFH8h2Hsh8YeXUwwmFmDfg85HhOJDPi6iJslWJAJ

