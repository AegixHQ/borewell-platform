--
-- PostgreSQL database dump
--

\restrict oCdgQbWGPHlUKyUOE4j18xlWZm9MpAUT0vIPFHIptEhejGEkLZnxVS1khPNli6D

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: job_status; Type: TYPE; Schema: public; Owner: borewell
--

CREATE TYPE public.job_status AS ENUM (
    'lead',
    'site_location',
    'requirement',
    'estimation',
    'price_calculation',
    'quotation',
    'customer_approval',
    'booking',
    'resource_allocation',
    'drilling',
    'progress',
    'completion',
    'payment',
    'service_history'
);


ALTER TYPE public.job_status OWNER TO borewell;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: borewell
--

CREATE TYPE public.user_role AS ENUM (
    'customer',
    'contractor',
    'admin',
    'resource_owner'
);


ALTER TYPE public.user_role OWNER TO borewell;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: borewell
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO borewell;

--
-- Name: job_completions; Type: TABLE; Schema: public; Owner: borewell
--

CREATE TABLE public.job_completions (
    id character varying(36) NOT NULL,
    job_id character varying(36) NOT NULL,
    actual_depth_ft double precision NOT NULL,
    depth_overage_ft double precision DEFAULT '0'::double precision NOT NULL,
    actual_cost numeric(12,2) NOT NULL,
    quoted_total numeric(12,2) NOT NULL,
    variance numeric(12,2) NOT NULL,
    depth_overage_charge numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    completed_at timestamp without time zone NOT NULL
);


ALTER TABLE public.job_completions OWNER TO borewell;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: borewell
--

CREATE TABLE public.jobs (
    id character varying(36) NOT NULL,
    customer_id character varying(36) NOT NULL,
    contractor_id character varying(36),
    location_lat double precision NOT NULL,
    location_lng double precision NOT NULL,
    job_type character varying NOT NULL,
    status public.job_status NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    walk_in boolean DEFAULT false NOT NULL,
    customer_name character varying(100),
    customer_phone character varying(20)
);


ALTER TABLE public.jobs OWNER TO borewell;

--
-- Name: users; Type: TABLE; Schema: public; Owner: borewell
--

CREATE TABLE public.users (
    id character varying(36) NOT NULL,
    email character varying NOT NULL,
    phone character varying,
    password_hash character varying NOT NULL,
    role public.user_role NOT NULL,
    created_at timestamp without time zone,
    google_sub character varying
);


ALTER TABLE public.users OWNER TO borewell;

--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: borewell
--

COPY public.alembic_version (version_num) FROM stdin;
0005
\.


--
-- Data for Name: job_completions; Type: TABLE DATA; Schema: public; Owner: borewell
--

COPY public.job_completions (id, job_id, actual_depth_ft, depth_overage_ft, actual_cost, quoted_total, variance, depth_overage_charge, completed_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: borewell
--

COPY public.jobs (id, customer_id, contractor_id, location_lat, location_lng, job_type, status, created_at, updated_at, walk_in, customer_name, customer_phone) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: borewell
--

COPY public.users (id, email, phone, password_hash, role, created_at, google_sub) FROM stdin;
f6fda747-13cf-4b22-a037-43a5929e550c	hello@aegix.hi	\N	$2b$12$T8OBRT4JNNwwz6odTJ39P.7/20DDWVQqkrGwYCNXlxgRrI.5V48LO	admin	2026-09-03 18:52:46.106396	\N
18f90f0f-335f-44cc-b96c-92d6c4255db5	hello@aegix.contractor	\N	$2b$12$jVrG6lmL9mqYOJagouvVrONOMJhu3kuF31XPZtyaRShl.pg2o7Cqi	contractor	2026-09-03 18:54:38.218201	\N
79bfa07c-1f0d-464b-bd6d-ff483eca87d4	admin@example.com	\N	$2b$12$F0tD9NWdlTtkQ9bOGIb0Q.OpWNAUlauGHwx8TKTuIAPDSoVvmUivm	admin	2026-11-17 16:55:59.969536	\N
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: borewell
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: job_completions job_completions_pkey; Type: CONSTRAINT; Schema: public; Owner: borewell
--

ALTER TABLE ONLY public.job_completions
    ADD CONSTRAINT job_completions_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: borewell
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: borewell
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_job_completions_job_id; Type: INDEX; Schema: public; Owner: borewell
--

CREATE UNIQUE INDEX ix_job_completions_job_id ON public.job_completions USING btree (job_id);


--
-- Name: ix_jobs_contractor_id; Type: INDEX; Schema: public; Owner: borewell
--

CREATE INDEX ix_jobs_contractor_id ON public.jobs USING btree (contractor_id);


--
-- Name: ix_jobs_customer_id; Type: INDEX; Schema: public; Owner: borewell
--

CREATE INDEX ix_jobs_customer_id ON public.jobs USING btree (customer_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: borewell
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_google_sub; Type: INDEX; Schema: public; Owner: borewell
--

CREATE UNIQUE INDEX ix_users_google_sub ON public.users USING btree (google_sub);


--
-- PostgreSQL database dump complete
--

\unrestrict oCdgQbWGPHlUKyUOE4j18xlWZm9MpAUT0vIPFHIptEhejGEkLZnxVS1khPNli6D

