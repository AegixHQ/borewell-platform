--
-- PostgreSQL database dump
--

\restrict UtdsWtIzVWaDKqqbjTGZh2DVTpUlz6svKSbpoEej7Zm8lFx6QO2QEU0uIICnWly

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: resource_status; Type: TYPE; Schema: public; Owner: borewell
--

CREATE TYPE public.resource_status AS ENUM (
    'available',
    'reserved',
    'assigned',
    'in_use',
    'returned'
);


ALTER TYPE public.resource_status OWNER TO borewell;

--
-- Name: resource_type; Type: TYPE; Schema: public; Owner: borewell
--

CREATE TYPE public.resource_type AS ENUM (
    'rig',
    'equipment',
    'labour'
);


ALTER TYPE public.resource_type OWNER TO borewell;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: borewell
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO borewell;

--
-- Name: booking_requests; Type: TABLE; Schema: public; Owner: borewell
--

CREATE TABLE public.booking_requests (
    id character varying(36) NOT NULL,
    resource_id character varying(36) NOT NULL,
    owner_id character varying(36) NOT NULL,
    contractor_id character varying(36) NOT NULL,
    job_id character varying(36),
    status character varying DEFAULT 'pending'::character varying NOT NULL,
    message character varying,
    created_at timestamp without time zone,
    responded_at timestamp without time zone
);


ALTER TABLE public.booking_requests OWNER TO borewell;

--
-- Name: resources; Type: TABLE; Schema: public; Owner: borewell
--

CREATE TABLE public.resources (
    id character varying(36) NOT NULL,
    owner_id character varying(36) NOT NULL,
    resource_type public.resource_type NOT NULL,
    name character varying NOT NULL,
    status public.resource_status NOT NULL,
    notes character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    lat double precision,
    lng double precision,
    hourly_rate numeric(12,2),
    vehicle_type character varying
);


ALTER TABLE public.resources OWNER TO borewell;

--
-- Name: service_areas; Type: TABLE; Schema: public; Owner: borewell
--

CREATE TABLE public.service_areas (
    id character varying(36) NOT NULL,
    name character varying NOT NULL,
    district character varying NOT NULL,
    state character varying NOT NULL,
    center_lat double precision NOT NULL,
    center_lng double precision NOT NULL,
    radius_km double precision NOT NULL,
    estimated_water_depth_ft double precision NOT NULL,
    confidence_band_ft double precision NOT NULL,
    source character varying DEFAULT 'contractor_estimate'::character varying NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE public.service_areas OWNER TO borewell;

--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: borewell
--

COPY public.alembic_version (version_num) FROM stdin;
0002
\.


--
-- Data for Name: booking_requests; Type: TABLE DATA; Schema: public; Owner: borewell
--

COPY public.booking_requests (id, resource_id, owner_id, contractor_id, job_id, status, message, created_at, responded_at) FROM stdin;
\.


--
-- Data for Name: resources; Type: TABLE DATA; Schema: public; Owner: borewell
--

COPY public.resources (id, owner_id, resource_type, name, status, notes, created_at, updated_at, lat, lng, hourly_rate, vehicle_type) FROM stdin;
e5f0a841-e417-4131-b3a9-20958794ca9a	18f90f0f-335f-44cc-b96c-92d6c4255db5	rig	alpha	in_use		2026-09-03 18:54:59.785981	2026-09-03 18:55:37.560083	\N	\N	\N	\N
\.


--
-- Data for Name: service_areas; Type: TABLE DATA; Schema: public; Owner: borewell
--

COPY public.service_areas (id, name, district, state, center_lat, center_lng, radius_km, estimated_water_depth_ft, confidence_band_ft, source, updated_at) FROM stdin;
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: borewell
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: booking_requests booking_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: borewell
--

ALTER TABLE ONLY public.booking_requests
    ADD CONSTRAINT booking_requests_pkey PRIMARY KEY (id);


--
-- Name: resources resources_pkey; Type: CONSTRAINT; Schema: public; Owner: borewell
--

ALTER TABLE ONLY public.resources
    ADD CONSTRAINT resources_pkey PRIMARY KEY (id);


--
-- Name: service_areas service_areas_pkey; Type: CONSTRAINT; Schema: public; Owner: borewell
--

ALTER TABLE ONLY public.service_areas
    ADD CONSTRAINT service_areas_pkey PRIMARY KEY (id);


--
-- Name: ix_booking_requests_contractor_id; Type: INDEX; Schema: public; Owner: borewell
--

CREATE INDEX ix_booking_requests_contractor_id ON public.booking_requests USING btree (contractor_id);


--
-- Name: ix_booking_requests_owner_id; Type: INDEX; Schema: public; Owner: borewell
--

CREATE INDEX ix_booking_requests_owner_id ON public.booking_requests USING btree (owner_id);


--
-- Name: ix_booking_requests_resource_id; Type: INDEX; Schema: public; Owner: borewell
--

CREATE INDEX ix_booking_requests_resource_id ON public.booking_requests USING btree (resource_id);


--
-- Name: ix_resources_contractor_id; Type: INDEX; Schema: public; Owner: borewell
--

CREATE INDEX ix_resources_contractor_id ON public.resources USING btree (owner_id);


--
-- PostgreSQL database dump complete
--

\unrestrict UtdsWtIzVWaDKqqbjTGZh2DVTpUlz6svKSbpoEej7Zm8lFx6QO2QEU0uIICnWly

