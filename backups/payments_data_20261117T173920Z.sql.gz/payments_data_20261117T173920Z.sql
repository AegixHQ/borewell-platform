--
-- PostgreSQL database dump
--

\restrict Q2WgfZ4pWcEmcjmciJyWalKtDh66babOjD2r77y2MtVENejBcjIA1nVfs7dj2i6

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: payment_status; Type: TYPE; Schema: public; Owner: borewell
--

CREATE TYPE public.payment_status AS ENUM (
    'pending',
    'completed',
    'failed'
);


ALTER TYPE public.payment_status OWNER TO borewell;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: borewell
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO borewell;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: borewell
--

CREATE TABLE public.payments (
    id character varying(36) NOT NULL,
    job_id character varying(36) NOT NULL,
    quotation_id character varying(36) NOT NULL,
    customer_id character varying(36) NOT NULL,
    amount numeric(12,2) NOT NULL,
    idempotency_key character varying NOT NULL,
    status public.payment_status NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    razorpay_order_id character varying,
    razorpay_payment_id character varying,
    method character varying(10) DEFAULT 'online'::character varying NOT NULL,
    cash_confirmed_by character varying(36),
    cash_confirmed_at timestamp without time zone
);


ALTER TABLE public.payments OWNER TO borewell;

--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: borewell
--

COPY public.alembic_version (version_num) FROM stdin;
0004
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: borewell
--

COPY public.payments (id, job_id, quotation_id, customer_id, amount, idempotency_key, status, created_at, updated_at, razorpay_order_id, razorpay_payment_id, method, cash_confirmed_by, cash_confirmed_at) FROM stdin;
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: borewell
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: borewell
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: ix_payments_customer_id; Type: INDEX; Schema: public; Owner: borewell
--

CREATE INDEX ix_payments_customer_id ON public.payments USING btree (customer_id);


--
-- Name: ix_payments_idempotency_key; Type: INDEX; Schema: public; Owner: borewell
--

CREATE UNIQUE INDEX ix_payments_idempotency_key ON public.payments USING btree (idempotency_key);


--
-- Name: ix_payments_job_id; Type: INDEX; Schema: public; Owner: borewell
--

CREATE INDEX ix_payments_job_id ON public.payments USING btree (job_id);


--
-- Name: ix_payments_quotation_id; Type: INDEX; Schema: public; Owner: borewell
--

CREATE INDEX ix_payments_quotation_id ON public.payments USING btree (quotation_id);


--
-- Name: ix_payments_razorpay_order_id; Type: INDEX; Schema: public; Owner: borewell
--

CREATE INDEX ix_payments_razorpay_order_id ON public.payments USING btree (razorpay_order_id);


--
-- Name: ix_payments_razorpay_payment_id; Type: INDEX; Schema: public; Owner: borewell
--

CREATE INDEX ix_payments_razorpay_payment_id ON public.payments USING btree (razorpay_payment_id);


--
-- PostgreSQL database dump complete
--

\unrestrict Q2WgfZ4pWcEmcjmciJyWalKtDh66babOjD2r77y2MtVENejBcjIA1nVfs7dj2i6

